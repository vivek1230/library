package com.example.library.library.exceptions;



public class InvalidBookException extends LibraryException {
    public InvalidBookException(String message) {
        super(message);
    }
}

