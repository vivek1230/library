package com.example.library.library.services.searchParameters;

public interface SearchParameter {
}
