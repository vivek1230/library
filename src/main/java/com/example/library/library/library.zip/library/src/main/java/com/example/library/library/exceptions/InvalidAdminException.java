package com.example.library.library.exceptions;

public class InvalidAdminException extends LibraryException {
    public InvalidAdminException(String message) {
        super(message);
    }
}

