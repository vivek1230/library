package com.example.library.library.exceptions;

public class InvalidStudentException extends LibraryException {
    public InvalidStudentException(String message) {
        super(message);
    }
}
