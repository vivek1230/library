package com.example.library.library.models;

public enum Gender {
    FEMALE,
    MALE,
    NON_BINARY
}
